function print_prompt(times)
    local write = io.write

    for i = 1, times, 1 do
        write(">")
    end
    
    write(" ")
end

function read_string()
    return read_string("*l")
end

write = io.write
read_string = io.read

write("Lua simple shell\n")
write("Enter quit to exit.\n")

-- Simple REPL in Lua.
level = 1
print_prompt(level)
command_string = read_string()
while (command_string ~= "quit") do
    -- Run the given command. The output is written on the screen.
    -- assert(loadstring(command_string))()
    out_string, err_string = loadstring(command_string)
    if (out_string ~= nil) then
        -- Success!
        out_string()
    else
        -- FIXME: handle a continuous command (for instance, if).
        -- Something went wrong!
        write(err_string, "\n")
    end

    level = 1
    print_prompt(level)
    command_string = read_string()
end
