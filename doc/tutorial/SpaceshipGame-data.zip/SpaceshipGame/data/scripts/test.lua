print("From a file")

function LuaExp(value)
    return math.exp(value)
end

luaX = 10
luaTable = {x = 10.0, y = 20.0, message = "Hello, world!"}
