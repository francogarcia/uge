-- Print all the Lua global variables.
function PrintGlobals()
    for key, value in pairs(_G) do
        print(key, value)
    end
end


