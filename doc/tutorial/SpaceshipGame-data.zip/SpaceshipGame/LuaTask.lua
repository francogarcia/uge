-- require("PreInit.lua")

-- To run in a Lua shell: ExecuteFile("LuaTask.lua")

TestScriptTask = class(ScriptTask,
                       {
                           count = 0
                       })

function TestScriptTask:OnInit()
    print("OnInit()")
end

function TestScriptTask:OnUpdate(fDeltaTms)
    self.count = self.count + 1
    print("OnUpdate(): Count: " .. self.count)
    
    if (self.count >= 5) then
        self:Succeed()
    end
end

function TestScriptTask:OnSuccess()
    print("OnSuccess()")
end

-- Some tests
parent = TestScriptTask:Create({frequency = 100})
child = TestScriptTask:Create({frequency = 50})
parent:AttachChild(child)
AttachTask(parent)
