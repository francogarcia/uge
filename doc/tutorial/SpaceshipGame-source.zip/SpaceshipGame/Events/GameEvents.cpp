#include "SpaceshipGameStd.h"

#include "GameEvents.h"

namespace sg
{
    const uge::EventType EvtData_Restart_Game::sk_EventType(0x2f2cf52c); 
}