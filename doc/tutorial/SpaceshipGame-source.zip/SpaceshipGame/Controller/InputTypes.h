#pragma once

#include <IO/Input/InputMapping/InputTypes.h>

enum class uge::InputMapping::Action : unsigned int
{

};

enum class uge::InputMapping::State : unsigned int
{
    Player1MoveUp,
    Player1MoveDown,
    Player2MoveUp,
    Player2MoveDown
};

enum class uge::InputMapping::Range : unsigned int
{

};
