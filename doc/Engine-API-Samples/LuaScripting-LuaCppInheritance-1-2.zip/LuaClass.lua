-- require("PreInit.lua")

-- To run in a Lua shell: ExecuteFile("LuaClass.lua")

LuaCppClass = class(CPP,
                    {
                        -- Attributes declared here are Lua only.
                        m_Name = "Lua Class"
                    })

function LuaCppClass:vPrint()
    --                                 C++ attribute               Lua attribute
    print("Lua class inheritance: " .. self:vGetValue() .. " - " .. self.m_Name)
end

-- Some tests
test = LuaCppClass:Create({m_Value = 100})
test:vPrint()

anotherTest = LuaCppClass:Create({m_Name = "Second Lua class"})
anotherTest:vPrint()
