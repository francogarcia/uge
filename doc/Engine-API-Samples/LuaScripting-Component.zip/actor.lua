
function CreateActor(scriptObject)
    print("[Lua] Creating actor...")
    
    -- Add or initialize data members.
    scriptObject.m_DataValue = "Additional data"
    
    print(scriptObject)
end

function DestroyActor(scriptObject)
    print("[Lua] Destroying actor...")
end
