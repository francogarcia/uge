-- require("PreInit.lua")

-- To run in a Lua shell: ExecuteFile("LuaTask.lua")

TestScriptTask = class(ScriptTask,
                       {
                           m_Count = 0
                       })

function TestScriptTask:OnInit()
    print("OnInit()")
end

function TestScriptTask:OnUpdate(fDeltaTms)
    self.m_Count = self.m_Count + 1
    print("OnUpdate(): Count: " .. self.m_Count)
    
    if (self.m_Count >= 5) then
        self:Succeed()
    end
end

function TestScriptTask:OnSuccess()
    print("OnSuccess()")
end

-- Some tests
parent = TestScriptTask:Create({m_Frequency = 100})
child = TestScriptTask:Create({m_Frequency = 50})
parent:AttachChild(child)
AttachTask(parent)
