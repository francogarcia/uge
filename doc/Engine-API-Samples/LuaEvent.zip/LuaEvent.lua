-- require("PreInit.lua")

function LuaEventHandler(eventData)
    print("[Lua - LuaEventHandler()]")
    print("     -> Event 'ScriptEventToLua' received! Value = " .. eventData)
    print("")
    eventData = eventData + 1
    
    -- Send event to C++.
    QueueEvent(EventType.ScriptEventFromLua, eventData)
end

function LuaScriptEventListener(eventData)
    print("[Lua - LuaScriptEventListener()]")
    print("     -> Event 'LuaScriptEvent' received! Value = " .. eventData)
    print("")
end

print(EventType)

-- Listen from C++ event and handle it.
RegisterEventListener(EventType.ScriptEventToLua, LuaEventHandler)
RegisterEventListener(EventType.LuaScriptEvent, LuaScriptEventListener)
